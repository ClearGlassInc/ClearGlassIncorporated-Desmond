#Requires -RunAsAdministrator
#Requires -Version 5.1
<#
.SYNOPSIS
    ClearGlassCorp AEGIS SENTINEL - Advanced Endpoint Defense Platform

.DESCRIPTION
    Enterprise-grade endpoint detection and response (EDR) platform with AI-powered
    threat detection, behavioral analytics, memory forensics, and predictive threat modeling.
    
    ENTERPRISE CAPABILITIES:
    ├─ AI/ML Behavioral Analytics Engine
    ├─ Memory Forensics & Rootkit Detection
    ├─ Zero-Day Exploit Detection (Heuristic)
    ├─ Advanced Network Traffic Analysis
    ├─ Kernel-Level Integrity Monitoring
    ├─ Supply Chain Attack Detection
    ├─ APT (Advanced Persistent Threat) Hunting
    ├─ Predictive Threat Modeling
    ├─ BIOS/Firmware Integrity Verification
    ├─ Advanced Evasion Technique Detection
    ├─ Cross-Correlation Threat Engine
    └─ Real-Time Threat Intelligence Integration

.NOTES
    Product: ClearGlassCorp AEGIS SENTINEL
    Version: 3.0.1 - Enterprise Edition
    Build: 20260109-ENTERPRISE
    Classification: Defense Grade
    Copyright: © 2026 ClearGlassCorp. All Rights Reserved.
    Contact: support@clearglasscorp.com
    Website: https://clearglasscorp.com
    
    Requirements:
    - Windows Server 2019+ / Windows 10 20H2+
    - PowerShell 5.1+ (7.x recommended)
    - 8GB RAM minimum (16GB recommended)
    - Administrator privileges
    - .NET Framework 4.8+

.PARAMETER Mode
    Operation mode: Deploy, Monitor, Hunt, Investigate, Audit, Dashboard, Research

.PARAMETER ThreatLevel
    Detection sensitivity: Standard, Aggressive, Paranoid

.PARAMETER EnableML
    Enable machine learning behavioral analytics

.PARAMETER EnableForensics
    Enable memory forensics and deep inspection

.PARAMETER ResearchMode
    Enable experimental detection algorithms

.PARAMETER AutoRemediate
    Enable automated threat containment (use with caution)

.PARAMETER DeployDeception
    Deploy honeypot and honeytoken artifacts

.PARAMETER Silent
    Suppress console output

.EXAMPLE
    .\AEGIS-SENTINEL.ps1 -Mode Dashboard -ThreatLevel Aggressive -EnableML
    Launch advanced dashboard with ML-powered detection

.EXAMPLE
    .\AEGIS-SENTINEL.ps1 -Mode Hunt -EnableForensics -ResearchMode
    Advanced threat hunting with memory forensics

.EXAMPLE
    .\AEGIS-SENTINEL.ps1 -Mode Investigate -IncidentID "APT-2026-001"
    Deep dive investigation with full forensics

.EXAMPLE
    .\AEGIS-SENTINEL.ps1 -Mode Deploy -DeployDeception
    Deploy hardening configurations and deception artifacts
#>

[CmdletBinding()]
param(
    [Parameter()]
    [ValidateSet('Deploy', 'Monitor', 'Hunt', 'Investigate', 'Audit', 'Dashboard', 'Research')]
    [string]$Mode = 'Dashboard',

    [Parameter()]
    [ValidateSet('Standard', 'Aggressive', 'Paranoid')]
    [string]$ThreatLevel = 'Standard',

    [Parameter()]
    [string]$IncidentID,

    [Parameter()]
    [ValidateRange(30, 86400)]
    [int]$HuntDuration = 300,

    [Parameter()]
    [switch]$EnableML,

    [Parameter()]
    [switch]$EnableForensics,

    [Parameter()]
    [switch]$ResearchMode,

    [Parameter()]
    [switch]$AutoRemediate,

    [Parameter()]
    [switch]$DeployDeception,

    [Parameter()]
    [switch]$Silent
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION MATRIX
# ═══════════════════════════════════════════════════════════════════════════════

$Script:AEGIS = @{
    Product = @{
        Name        = "AEGIS SENTINEL"
        Version     = "3.0.1"
        Codename    = "ENTERPRISE"
        Build       = "20260109-ENTERPRISE"
        Classification = "Defense Grade"
        Copyright   = "© 2026 ClearGlassCorp"
        Website     = "https://clearglasscorp.com"
    }

    # Adaptive threat detection thresholds based on ThreatLevel
    Thresholds = @{
        Standard = @{
            AnomalyScore  = 75
            ProcessScore  = 70
            NetworkScore  = 80
            MemoryScore   = 85
            BehaviorScore = 70
        }
        Aggressive = @{
            AnomalyScore  = 60
            ProcessScore  = 55
            NetworkScore  = 65
            MemoryScore   = 70
            BehaviorScore = 55
        }
        Paranoid = @{
            AnomalyScore  = 45
            ProcessScore  = 40
            NetworkScore  = 50
            MemoryScore   = 55
            BehaviorScore = 40
        }
    }

    # Machine Learning Configuration
    ML = @{
        Enabled             = $EnableML
        BaselineSamples     = 1000
        ConfidenceThreshold = 0.85
        RetrainingInterval  = 3600
        AnomalyDetectionAlgo = 'IsolationForest'
        BehaviorProfiling   = $true
    }

    # Advanced Detection Capabilities
    Advanced = @{
        MemoryForensics       = $EnableForensics
        KernelMonitoring      = $true
        RootkitDetection      = $true
        ZeroDayHeuristics     = $true
        SupplyChainMonitoring = $true
        FirmwareIntegrity     = $true
        DeepPacketInspection  = $false
        QuantumCryptoCheck    = $true
        ContainerSecurity     = $true
        APTDetection          = $true
    }

    # Correlation Engine
    Correlation = @{
        Enabled                  = $true
        CorrelationWindow        = 3600
        MinEventsForCorrelation  = 3
        ThreatPatterns = @(
            'Reconnaissance',
            'InitialAccess',
            'Execution',
            'Persistence',
            'PrivilegeEscalation',
            'DefenseEvasion',
            'Discovery',
            'LateralMovement',
            'Collection',
            'Exfiltration',
            'Impact'
        )
    }

    # Threat Intelligence
    ThreatIntel = @{
        Enabled        = $true
        UpdateInterval = 3600
        Sources = @(
            'Local',
            'MicrosoftDefender',
            'EventLog'
        )
    }

    # Logging & Forensics
    Logging = @{
        BasePath          = "$env:ProgramData\ClearGlassCorp\AEGIS\Logs"
        ThreatLog         = "Threats"
        ForensicsLog      = "Forensics"
        AuditLog          = "Audit"
        ResearchLog       = "Research"
        MLLog             = "MachineLearning"
        NetworkLog        = "Network"
        MemoryLog         = "Memory"
        RetentionDays     = 365
        EnableCompression = $true
    }

    # Dashboard Configuration
    Dashboard = @{
        RefreshInterval  = 3
        MaxAlerts        = 15
        MaxMetrics       = 50
        EnableAnimations = $true
        ColorScheme      = 'Military'
        ShowMLInsights   = $EnableML
        ShowForensics    = $EnableForensics
    }
}

# ═══════════════════════════════════════════════════════════════════════════════
# INITIALIZE LOGGING DIRECTORIES
# ═══════════════════════════════════════════════════════════════════════════════

$basePath = $Script:AEGIS.Logging.BasePath
$logTypes = @('Threats', 'Forensics', 'Audit', 'Research', 'MachineLearning', 'Network', 'Memory', 'Incidents')

if (-not (Test-Path $basePath)) {
    New-Item -ItemType Directory -Path $basePath -Force | Out-Null
}

foreach ($logType in $logTypes) {
    $logPath = Join-Path $basePath $logType
    if (-not (Test-Path $logPath)) {
        New-Item -ItemType Directory -Path $logPath -Force | Out-Null
    }

    try {
        $acl = Get-Acl $logPath
        $acl.SetAccessRuleProtection($true, $true)

        $sysRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            "NT AUTHORITY\SYSTEM", "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow"
        )
        $admRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            "BUILTIN\Administrators", "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow"
        )
        $userPrincipal = "$env:USERDOMAIN\$env:USERNAME"
        $usrRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $userPrincipal, "Modify", "ContainerInherit,ObjectInherit", "None", "Allow"
        )

        $null = $acl.AddAccessRule($sysRule)
        $null = $acl.AddAccessRule($admRule)
        $null = $acl.AddAccessRule($usrRule)

        Set-Acl -Path $logPath -AclObject $acl
    } catch {
        # Continue if ACL fails
    }
}

$Script:IncidentsDir = Join-Path $basePath "Incidents"

# Global State
$Script:AlertQueue = [System.Collections.Generic.List[object]]::new()
$Script:ThreatCount = 0
$Script:SessionStart = Get-Date
$Script:ActiveJobs = @()
$Script:MLBaseline = $null
$Script:DisabledAdapters = @()

# ═══════════════════════════════════════════════════════════════════════════════
# CLEANUP HANDLER
# ═══════════════════════════════════════════════════════════════════════════════

$Script:CleanupBlock = {
    Write-Host "`nShutting down AEGIS SENTINEL..." -ForegroundColor Yellow

    foreach ($job in $Script:ActiveJobs) {
        if ($job -and $job.State -eq 'Running') {
            Stop-Job -Job $job -ErrorAction SilentlyContinue
            Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
        }
    }

    if ($Script:DisabledAdapters -and $Script:DisabledAdapters.Count -gt 0) {
        Write-Host "Re-enabling network adapters..." -ForegroundColor Yellow
        foreach ($adapter in $Script:DisabledAdapters) {
            Enable-NetAdapter -Name $adapter -Confirm:$false -ErrorAction SilentlyContinue
        }
    }

    Write-Host "AEGIS SENTINEL shutdown complete." -ForegroundColor Green
}

$null = Register-EngineEvent -SourceIdentifier PowerShell.Exiting -Action $Script:CleanupBlock -ErrorAction SilentlyContinue

# ═══════════════════════════════════════════════════════════════════════════════
# LOGGING SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

function Write-AegisLog {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('INFO','SUCCESS','WARNING','ERROR','CRITICAL','THREAT','FORENSIC','ML','RESEARCH')]
        [string]$Level = 'INFO',
        [string]$Component = 'CORE',
        [hashtable]$Metadata = @{},
        [int]$ThreatScore = 0
    )

    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'
    $category = switch ($Level) {
        'THREAT'   { 'Threats' }
        'FORENSIC' { 'Forensics' }
        'ML'       { 'MachineLearning' }
        'RESEARCH' { 'Research' }
        default    { 'Audit' }
    }

    $logDir = Join-Path $Script:AEGIS.Logging.BasePath $category
    $logFile = Join-Path $logDir "AEGIS_$(Get-Date -Format 'yyyyMMdd').log"

    $logEntry = [PSCustomObject]@{
        Timestamp   = $timestamp
        Level       = $Level
        Component   = $Component
        Message     = $Message
        Computer    = $env:COMPUTERNAME
        User        = $env:USERNAME
        Domain      = $env:USERDOMAIN
        ProcessId   = $PID
        ThreatScore = $ThreatScore
        Metadata    = $Metadata
    }

    try {
        if (-not (Test-Path $logDir)) {
            New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        }
        $logEntry | ConvertTo-Json -Compress | Add-Content -Path $logFile -ErrorAction Stop
    } catch {}

    if (-not $Silent) {
        $color = switch ($Level) {
            'SUCCESS'  { 'Green' }
            'WARNING'  { 'Yellow' }
            'ERROR'    { 'Red' }
            'CRITICAL' { 'Red' }
            'THREAT'   { 'Magenta' }
            'FORENSIC' { 'Cyan' }
            'ML'       { 'Blue' }
            'RESEARCH' { 'DarkCyan' }
            default    { 'White' }
        }
        $icon = switch ($Level) {
            'SUCCESS'  { '[+]' }
            'WARNING'  { '[!]' }
            'ERROR'    { '[X]' }
            'CRITICAL' { '[!!]' }
            'THREAT'   { '[T]' }
            'FORENSIC' { '[F]' }
            'ML'       { '[ML]' }
            'RESEARCH' { '[R]' }
            default    { '[*]' }
        }

        if ($ThreatScore -ge 80) {
            Write-Host "[$timestamp] $icon [$Level] [Score:$ThreatScore] $Message" -ForegroundColor $color
        } else {
            Write-Host "[$timestamp] $icon [$Level] $Message" -ForegroundColor $color
        }
    }
}

# ═══════════════════════════════════════════════════════════════════════════════
# MACHINE LEARNING BEHAVIORAL ANALYTICS
# ═══════════════════════════════════════════════════════════════════════════════

function Initialize-MLBaseline {
    Write-AegisLog "Initializing ML behavioral baseline..." -Level ML -Component ML_ENGINE

    $mlDir = Join-Path $Script:AEGIS.Logging.BasePath "MachineLearning"
    if (-not (Test-Path $mlDir)) { New-Item -ItemType Directory -Path $mlDir -Force | Out-Null }
    $baselinePath = Join-Path $mlDir "baseline.json"

    if (Test-Path $baselinePath) {
        try {
            $Script:MLBaseline = Get-Content $baselinePath -Raw | ConvertFrom-Json
            Write-AegisLog "ML baseline loaded: $($Script:MLBaseline.SampleCount) samples" -Level SUCCESS -Component ML_ENGINE
            return $Script:MLBaseline
        } catch {
            Write-AegisLog "Failed to load baseline, creating new" -Level WARNING -Component ML_ENGINE
        }
    }

    Write-AegisLog "Building new ML baseline..." -Level INFO -Component ML_ENGINE

    $processes = Get-Process -ErrorAction SilentlyContinue
    $connections = Get-NetTCPConnection -ErrorAction SilentlyContinue
    $logons = Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624} -MaxEvents 500 -ErrorAction SilentlyContinue
    
    try {
        $cpuCounter = Get-Counter '\Processor(_Total)\% Processor Time' -ErrorAction SilentlyContinue
        $cpu = if ($cpuCounter) { $cpuCounter.CounterSamples.CookedValue } else { 0 }
    } catch { $cpu = 0 }
    
    $mem = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue

    $baseline = @{
        Created = (Get-Date).ToString('o')
        SampleCount = 1
        ProcessBehavior = @{
            Count       = @($processes).Count
            AvgCPU      = ($processes | Measure-Object -Property CPU -Average -ErrorAction SilentlyContinue).Average
            AvgMemory   = ($processes | Measure-Object -Property WorkingSet64 -Average -ErrorAction SilentlyContinue).Average
            UniqueNames = @($processes.Name | Select-Object -Unique).Count
        }
        NetworkBehavior = @{
            TotalConnections = @($connections).Count
            EstablishedConns = @($connections | Where-Object State -eq 'Established').Count
            ListeningPorts   = @($connections | Where-Object State -eq 'Listen' | Select-Object -ExpandProperty LocalPort -Unique).Count
            UniqueRemoteIPs  = @($connections | Where-Object State -eq 'Established' | Select-Object -ExpandProperty RemoteAddress -Unique).Count
        }
        UserBehavior = @{
            LogonCount  = @($logons).Count
            UniqueUsers = @($logons | ForEach-Object { $_.Properties[5].Value } | Select-Object -Unique).Count
        }
        SystemBehavior = @{
            BaselineCPU = [double]$cpu
            BaselineMemoryUsed = if ($mem -and $mem.TotalVisibleMemorySize -gt 0) {
                (($mem.TotalVisibleMemorySize - $mem.FreePhysicalMemory) / $mem.TotalVisibleMemorySize) * 100
            } else { 0 }
            Timestamp = (Get-Date).ToString('o')
        }
    }

    try {
        $baseline | ConvertTo-Json -Depth 10 | Set-Content -Path $baselinePath -Encoding UTF8
    } catch {
        Write-AegisLog "Failed to save baseline" -Level WARNING -Component ML_ENGINE
    }
    
    $Script:MLBaseline = [PSCustomObject]$baseline
    Write-AegisLog "ML baseline created successfully" -Level SUCCESS -Component ML_ENGINE
    return $baseline
}

function Test-BehavioralAnomaly {
    param([hashtable]$CurrentState)

    if (-not $Script:MLBaseline) { return @() }

    $anomalies = @()

    $baselineProcessCount = if ($Script:MLBaseline.ProcessBehavior -and $Script:MLBaseline.ProcessBehavior.Count) {
        $Script:MLBaseline.ProcessBehavior.Count
    } else { 100 }

    $baselineNetworkConns = if ($Script:MLBaseline.NetworkBehavior -and $Script:MLBaseline.NetworkBehavior.TotalConnections) {
        $Script:MLBaseline.NetworkBehavior.TotalConnections
    } else { 50 }

    $baselineCPU = if ($Script:MLBaseline.SystemBehavior -and $Script:MLBaseline.SystemBehavior.BaselineCPU) {
        $Script:MLBaseline.SystemBehavior.BaselineCPU
    } else { 20 }

    if ($CurrentState.ProcessCount -and $CurrentState.ProcessCount -gt ($baselineProcessCount * 1.5)) {
        $anomalies += @{
            Type     = 'ProcessAnomaly'
            Severity = 'MEDIUM'
            Score    = 65
            Details  = "Process count spike: $($CurrentState.ProcessCount) vs baseline $baselineProcessCount"
            Timestamp = Get-Date
        }
    }

    if ($CurrentState.NetworkConnections -and $CurrentState.NetworkConnections -gt ($baselineNetworkConns * 2)) {
        $anomalies += @{
            Type     = 'NetworkAnomaly'
            Severity = 'HIGH'
            Score    = 75
            Details  = "Network activity spike: $($CurrentState.NetworkConnections) connections"
            Timestamp = Get-Date
        }
    }

    if ($CurrentState.CPU -and $CurrentState.CPU -gt ($baselineCPU + 40)) {
        $anomalies += @{
            Type     = 'SystemAnomaly'
            Severity = 'MEDIUM'
            Score    = 60
            Details  = "CPU anomaly: $($CurrentState.CPU)% vs baseline $baselineCPU%"
            Timestamp = Get-Date
        }
    }

    return $anomalies
}

# ═══════════════════════════════════════════════════════════════════════════════
# MEMORY FORENSICS & ROOTKIT DETECTION
# ═══════════════════════════════════════════════════════════════════════════════

function Start-MemoryForensics {
    Write-AegisLog "Initiating memory forensics scan..." -Level FORENSIC -Component MEMORY_FORENSICS
    $findings = @()

    # Hidden process detection
    Write-Host "  [FORENSICS] Scanning for hidden processes..." -ForegroundColor Cyan
    try {
        $wmicProcs = @(Get-WmiObject Win32_Process -ErrorAction SilentlyContinue | Select-Object -ExpandProperty ProcessId)
        $psProcs = @(Get-Process -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id)

        if ($wmicProcs -and $psProcs) {
            $hidden = Compare-Object $wmicProcs $psProcs -ErrorAction SilentlyContinue | Where-Object { $_.SideIndicator -eq '<=' }

            if ($hidden) {
                $hiddenCount = @($hidden).Count
                $findings += @{
                    Type      = 'HiddenProcess'
                    Severity  = 'CRITICAL'
                    Score     = 95
                    Count     = $hiddenCount
                    Details   = "Hidden processes detected: $($hidden.InputObject -join ', ')"
                    Timestamp = Get-Date
                }
                Write-AegisLog "CRITICAL: Hidden processes detected" -Level THREAT -Component MEMORY_FORENSICS -ThreatScore 95
            }
        }
    } catch {
        Write-AegisLog "Hidden process scan failed: $_" -Level WARNING -Component MEMORY_FORENSICS
    }

    # LSASS module review
    Write-Host "  [FORENSICS] Checking LSASS integrity..." -ForegroundColor Cyan
    try {
        $lsass = Get-Process lsass -ErrorAction SilentlyContinue
        if ($lsass) {
            $modules = $lsass.Modules | Where-Object {
                $_.FileName -and $_.FileName -notlike "$env:SystemRoot\System32\*"
            }

            if ($modules) {
                $moduleCount = @($modules).Count
                $findings += @{
                    Type      = 'LSASSModuleAnomaly'
                    Severity  = 'HIGH'
                    Score     = 88
                    Count     = $moduleCount
                    Details   = "Non-System32 modules in LSASS: $($modules.FileName -join ', ')"
                    Timestamp = Get-Date
                }
                Write-AegisLog "LSASS module anomaly detected" -Level THREAT -Component MEMORY_FORENSICS -ThreatScore 88
            }
        }
    } catch {
        Write-AegisLog "LSASS integrity check failed: $_" -Level WARNING -Component MEMORY_FORENSICS
    }

    # Non-system running drivers
    Write-Host "  [FORENSICS] Enumerating kernel drivers..." -ForegroundColor Cyan
    try {
        $drivers = Get-WmiObject Win32_SystemDriver -ErrorAction SilentlyContinue | Where-Object {
            $_.State -eq 'Running' -and $_.PathName -and $_.PathName -notlike "$env:SystemRoot\*"
        }

        if ($drivers) {
            $driverCount = @($drivers).Count
            $findings += @{
                Type      = 'NonSystemDriver'
                Severity  = 'HIGH'
                Score     = 80
                Count     = $driverCount
                Details   = "Running drivers outside system root: $($drivers.Name -join ', ')"
                Timestamp = Get-Date
            }
        }
    } catch {
        Write-AegisLog "Driver enumeration failed: $_" -Level WARNING -Component MEMORY_FORENSICS
    }

    Write-AegisLog "Memory forensics completed: $(@($findings).Count) finding(s)" -Level FORENSIC -Component MEMORY_FORENSICS
    return $findings
}

# ═══════════════════════════════════════════════════════════════════════════════
# DETECTION ENGINES
# ═══════════════════════════════════════════════════════════════════════════════

function Start-AdvancedDetection {
    Write-AegisLog "Starting advanced detection engines..." -Level INFO -Component DETECTION
    $jobs = @()
    $threshold = $Script:AEGIS.Thresholds[$ThreatLevel]

    # Engine 1: Zero-Day Heuristics
    $jobs += Start-Job -Name "ZeroDayHeuristics" -ScriptBlock {
        while ($true) {
            try {
                $recentProcs = Get-WinEvent -FilterHashtable @{ LogName='Security'; Id=4688 } -MaxEvents 200 -ErrorAction SilentlyContinue
                if ($recentProcs) {
                    $suspicious = @($recentProcs | Where-Object {
                        $_.Properties[5].Value -match 'powershell|cmd|wscript|cscript' -and
                        $_.Properties[6].Value -notmatch 'System32|SysWOW64'
                    })
                    if ($suspicious.Count -gt 5) {
                        [PSCustomObject]@{
                            Type      = 'ZeroDayIndicator'
                            Pattern   = 'SuspiciousScriptExecution'
                            Count     = $suspicious.Count
                            Score     = 75
                            Severity  = 'HIGH'
                            Timestamp = Get-Date
                        }
                    }
                }
            } catch {}
            Start-Sleep -Seconds 30
        }
    }

    # Engine 2: Supply Chain Monitor
    $jobs += Start-Job -Name "SupplyChainMonitor" -ScriptBlock {
        $cutoffMinutes = 15
        while ($true) {
            try {
                $cutoff = (Get-Date).AddMinutes(-$cutoffMinutes)

                $appEvents = Get-WinEvent -FilterHashtable @{ LogName='Application'; StartTime=$cutoff } -MaxEvents 300 -ErrorAction SilentlyContinue
                $suspiciousUpdates = @($appEvents | Where-Object { $_.Message -match 'update|install|download' -and $_.LevelDisplayName -eq 'Error' })

                if ($suspiciousUpdates.Count -gt 3) {
                    [PSCustomObject]@{
                        Type       = 'SupplyChainAnomaly'
                        EventCount = $suspiciousUpdates.Count
                        Score      = 70
                        Severity   = 'MEDIUM'
                        Timestamp  = Get-Date
                    }
                }

                $paths = @("$env:ProgramData", "$env:TEMP", "$env:Windir\Temp")
                foreach ($p in $paths) {
                    if (-not (Test-Path $p)) { continue }
                    $recent = Get-ChildItem -Path $p -Filter *.exe -File -ErrorAction SilentlyContinue |
                        Where-Object { $_.LastWriteTime -gt $cutoff } | Select-Object -First 10
                    foreach ($exe in $recent) {
                        $sig = Get-AuthenticodeSignature $exe.FullName -ErrorAction SilentlyContinue
                        if ($sig -and $sig.Status -ne 'Valid') {
                            [PSCustomObject]@{
                                Type      = 'UnsignedBinary'
                                File      = $exe.Name
                                Path      = $exe.FullName
                                Score     = 65
                                Severity  = 'MEDIUM'
                                Timestamp = Get-Date
                            }
                        }
                    }
                }
            } catch {}
            Start-Sleep -Seconds 60
        }
    }

    # Engine 3: APT Detection
    $jobs += Start-Job -Name "APTDetection" -ScriptBlock {
        while ($true) {
            try {
                $aptIndicators = 0

                $longRunning = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
                    $_.StartTime -and $_.StartTime -lt (Get-Date).AddHours(-24) -and
                    $_.Path -and ($_.Path -like '*\Temp\*' -or $_.Path -like '*\AppData\*')
                })
                if ($longRunning.Count -gt 0) { $aptIndicators += $longRunning.Count }

                $tasks = @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object {
                    $_.TaskPath -notlike '\Microsoft\*' -and $_.State -eq 'Ready'
                })
                if ($tasks.Count -gt 10) { $aptIndicators += 5 }

                $runKeys = @(
                    'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run',
                    'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
                )
                $persistCount = 0
                foreach ($key in $runKeys) {
                    if (Test-Path $key -ErrorAction SilentlyContinue) {
                        $items = Get-ItemProperty $key -ErrorAction SilentlyContinue
                        if ($items) {
                            $suspiciousItems = @($items.PSObject.Properties | Where-Object {
                                $_.Value -like '*\AppData\*' -or $_.Value -like '*\Temp\*'
                            })
                            $persistCount += $suspiciousItems.Count
                        }
                    }
                }
                if ($persistCount -gt 2) { $aptIndicators += $persistCount * 5 }

                if ($aptIndicators -gt 5) {
                    [PSCustomObject]@{
                        Type           = 'APTIndicators'
                        Score          = [Math]::Min(95, 50 + $aptIndicators * 5)
                        IndicatorCount = $aptIndicators
                        Severity       = 'CRITICAL'
                        Timestamp      = Get-Date
                    }
                }
            } catch {}
            Start-Sleep -Seconds 45
        }
    }

    # Engine 4: Network Anomalies
    $jobs += Start-Job -Name "NetworkAnomalyEngine" -ScriptBlock {
        while ($true) {
            try {
                $connections = @(Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue)
                if ($connections.Count -gt 0) {
                    $grouped = $connections | Group-Object RemoteAddress
                    $beaconing = @($grouped | Where-Object { $_.Count -gt 5 -and $_.Name -notmatch '^(192\.168|10\.|172\.(1[6-9]|2[0-9]|3[0-1])|127\.)' })
                    foreach ($beacon in $beaconing) {
                        [PSCustomObject]@{
                            Type            = 'NetworkBeaconing'
                            RemoteIP        = $beacon.Name
                            ConnectionCount = $beacon.Count
                            Score           = 75
                            Severity        = 'HIGH'
                            Timestamp       = Get-Date
                        }
                    }

                    $unusualPorts = @($connections | Where-Object {
                        $_.RemotePort -notin @(80,443,53,22,3389,445,139) -and
                        $_.RemoteAddress -notmatch '^(192\.168|10\.|172\.(1[6-9]|2[0-9]|3[0-1])|127\.)'
                    })
                    if ($unusualPorts.Count -gt 10) {
                        [PSCustomObject]@{
                            Type      = 'UnusualPortActivity'
                            Count     = $unusualPorts.Count
                            Ports     = @($unusualPorts.RemotePort | Select-Object -Unique | Select-Object -First 5)
                            Score     = 68
                            Severity  = 'MEDIUM'
                            Timestamp = Get-Date
                        }
                    }
                }
            } catch {}
            Start-Sleep -Seconds 25
        }
    }

    # Engine 5: Registry Monitor
    $jobs += Start-Job -Name "RegistryMonitor" -ScriptBlock {
        $last = (Get-Date).AddMinutes(-5)
        while ($true) {
            try {
                $events = Get-WinEvent -FilterHashtable @{ LogName='Security'; Id=4657; StartTime=$last } -MaxEvents 200 -ErrorAction SilentlyContinue
                $last = Get-Date
                if ($events) {
                    $critical = @($events | Where-Object { $_.Properties.Count -gt 6 -and ($_.Properties[6].Value -match 'Run|Services|Winlogon|Image File Execution') })
                    if ($critical.Count -gt 3) {
                        [PSCustomObject]@{
                            Type        = 'RegistryTampering'
                            ChangeCount = $critical.Count
                            Score       = 78
                            Severity    = 'HIGH'
                            Timestamp   = Get-Date
                        }
                    }
                }
            } catch {}
            Start-Sleep -Seconds 35
        }
    }

    # Engine 6: Evasion Detection
    $jobs += Start-Job -Name "EvasionDetection" -ScriptBlock {
        while ($true) {
            try {
                $evasionScore = 0
                $systemPath = "$env:SystemRoot\System32"
                if (Test-Path $systemPath) {
                    $recentFiles = @(Get-ChildItem $systemPath -File -ErrorAction SilentlyContinue |
                        Where-Object { $_.CreationTime -gt $_.LastWriteTime } | Select-Object -First 5)
                    if ($recentFiles.Count -gt 0) { $evasionScore += $recentFiles.Count * 10 }
                }

                if ($evasionScore -gt 30) {
                    [PSCustomObject]@{
                        Type      = 'EvasionTechniques'
                        Score     = [Math]::Min(90, $evasionScore)
                        Severity  = 'HIGH'
                        Timestamp = Get-Date
                    }
                }
            } catch {}
            Start-Sleep -Seconds 30
        }
    }

    # Engine 7: Baseline Analytics (if ML enabled)
    if ($Script:AEGIS.ML.Enabled -and $Script:MLBaseline) {
        $baselineData = @{
            ProcessCount = $Script:MLBaseline.ProcessBehavior.Count
            NetworkConns = $Script:MLBaseline.NetworkBehavior.TotalConnections
            BaselineCPU  = $Script:MLBaseline.SystemBehavior.BaselineCPU
        }

        $jobs += Start-Job -Name "BaselineAnalytics" -ScriptBlock {
            param($baseline)
            while ($true) {
                try {
                    $currentState = @{
                        ProcessCount       = @(Get-Process -ErrorAction SilentlyContinue).Count
                        NetworkConnections = @(Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue).Count
                        CPU                = 0
                    }

                    try {
                        $cpuCounter = Get-Counter '\Processor(_Total)\% Processor Time' -ErrorAction SilentlyContinue
                        if ($cpuCounter) { $currentState.CPU = $cpuCounter.CounterSamples.CookedValue }
                    } catch {}

                    if ($baseline -and $baseline.ProcessCount) {
                        if ($currentState.ProcessCount -gt ($baseline.ProcessCount * 1.5)) {
                            [PSCustomObject]@{
                                Type      = 'MLAnomaly'
                                Category  = 'ProcessSpike'
                                Current   = $currentState.ProcessCount
                                Baseline  = $baseline.ProcessCount
                                Score     = 70
                                Severity  = 'MEDIUM'
                                Timestamp = Get-Date
                            }
                        }
                    }
                } catch {}
                Start-Sleep -Seconds 45
            }
        } -ArgumentList $baselineData
    }

    $Script:ActiveJobs = $jobs
    Write-AegisLog "Detection engines active: $($jobs.Count)" -Level SUCCESS -Component DETECTION
    return $jobs
}

# ═══════════════════════════════════════════════════════════════════════════════
# THREAT CORRELATION ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

function Invoke-ThreatCorrelation {
    param([array]$Alerts)

    $alertArray = @($Alerts)
    if ($alertArray.Count -lt $Script:AEGIS.Correlation.MinEventsForCorrelation) { return @() }

    $correlated = @()

    $recon  = @($alertArray | Where-Object { $_.Type -match 'Network' })
    $access = @($alertArray | Where-Object { $_.Type -match 'LSASS|Registry' })
    $exec   = @($alertArray | Where-Object { $_.Type -match 'ZeroDay|APT|Evasion|Hidden' })

    if ($recon.Count -gt 0 -and $access.Count -gt 0 -and $exec.Count -gt 0) {
        $correlated += [PSCustomObject]@{
            Type        = 'CorrelatedPattern'
            Pattern     = 'Recon->Access->Execution'
            Confidence  = 0.85
            Score       = 92
            Severity    = 'CRITICAL'
            Timestamp   = Get-Date
            Details     = "Correlated attack chain observed across multiple engines"
        }
        Write-AegisLog "Correlated attack pattern detected" -Level THREAT -Component CORRELATION -ThreatScore 92
    }

    return $correlated
}

# ═══════════════════════════════════════════════════════════════════════════════
# THREAT RESPONSE & CONTAINMENT
# ═══════════════════════════════════════════════════════════════════════════════

function Invoke-ThreatResponse {
    param([Parameter(Mandatory)]$Alert)

    $incidentId = "AEGIS-$(Get-Date -Format 'yyyyMMdd-HHmmss')-$(Get-Random -Maximum 9999)"
    $Script:ThreatCount++

    $severity = if ($Alert.Severity) { [string]$Alert.Severity } else { 'MEDIUM' }
    $score = if ($Alert.Score) { [int]$Alert.Score } else { 50 }

    Write-AegisLog "THREAT DETECTED: $($Alert.Type) [$severity] - $incidentId" -Level THREAT -Component RESPONSE -ThreatScore $score -Metadata @{
        IncidentId = $incidentId
        AlertType  = $Alert.Type
    }

    try { if (-not (Test-Path $Script:IncidentsDir)) { New-Item -ItemType Directory -Path $Script:IncidentsDir -Force | Out-Null } } catch {}

    if ($score -ge 90 -and $AutoRemediate) {
        Write-AegisLog "CRITICAL threat: auto-remediation engaged" -Level CRITICAL -Component RESPONSE -ThreatScore $score

        if ($Silent) {
            Write-AegisLog "Silent mode: skipping network isolation to prevent self-lockout" -Level WARNING -Component RESPONSE
        } else {
            $confirm = Read-Host "CRITICAL. Disable ALL network adapters to isolate host? Type YES to proceed"
            if ($confirm -eq 'YES') {
                try {
                    $adapters = Get-NetAdapter | Where-Object Status -eq 'Up'
                    foreach ($adapter in $adapters) {
                        $Script:DisabledAdapters += $adapter.Name
                        Disable-NetAdapter -Name $adapter.Name -Confirm:$false -ErrorAction SilentlyContinue
                    }
                    Write-AegisLog "Host isolated (network adapters disabled)" -Level SUCCESS -Component RESPONSE
                } catch {
                    Write-AegisLog "Isolation failed: $($_.Exception.Message)" -Level ERROR -Component RESPONSE
                }
            } else {
                Write-AegisLog "Isolation canceled by operator" -Level WARNING -Component RESPONSE
            }
        }

        if ($Alert.PSObject.Properties.Name -contains 'Process' -and $Alert.Process) {
            try {
                Write-AegisLog "Attempting to terminate process: $($Alert.Process)" -Level WARNING -Component RESPONSE
                Get-Process -Name $Alert.Process -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
            } catch {}
        }
    } elseif ($score -ge 75) {
        Write-AegisLog "High-risk alert: manual intervention recommended" -Level WARNING -Component RESPONSE -ThreatScore $score
    }

    $report = @{
        IncidentId      = $incidentId
        Timestamp       = (Get-Date).ToString('o')
        Alert           = $Alert
        Severity        = $severity
        Score           = $score
        AutoRemediation = $AutoRemediate.IsPresent
        System = @{
            Computer = $env:COMPUTERNAME
            User     = $env:USERNAME
            Domain   = $env:USERDOMAIN
        }
    }

    $reportPath = Join-Path $Script:IncidentsDir "$incidentId.json"
    try { $report | ConvertTo-Json -Depth 10 | Set-Content -Path $reportPath -Encoding UTF8 } catch {}

    return $incidentId
}

function Restore-NetworkAdapters {
    if ($Script:DisabledAdapters -and $Script:DisabledAdapters.Count -gt 0) {
        Write-AegisLog "Restoring network connectivity..." -Level INFO -Component RECOVERY

        foreach ($adapterName in $Script:DisabledAdapters) {
            try {
                Enable-NetAdapter -Name $adapterName -Confirm:$false -ErrorAction Stop
                Write-AegisLog "Re-enabled adapter: $adapterName" -Level SUCCESS -Component RECOVERY
            } catch {
                Write-AegisLog "Failed to re-enable adapter $adapterName : $_" -Level ERROR -Component RECOVERY
            }
        }

        $Script:DisabledAdapters = @()
    } else {
        Write-Host "No adapters to restore." -ForegroundColor Yellow
    }
}

# ═══════════════════════════════════════════════════════════════════════════════
# ADVANCED DASHBOARD
# ═══════════════════════════════════════════════════════════════════════════════

function Show-AdvancedDashboard {
    Write-AegisLog "Launching Advanced Dashboard" -Level INFO -Component DASHBOARD

    if ($Script:AEGIS.ML.Enabled) { Initialize-MLBaseline | Out-Null }
    $detectionJobs = Start-AdvancedDetection

    if ($Script:AEGIS.Advanced.MemoryForensics) {
        $forensics = Start-MemoryForensics
        foreach ($f in @($forensics)) { $Script:AlertQueue.Add($f) }
    }

    try {
        while ($true) {
            Clear-Host

            Write-Host @"
================================================================================
                                                                              
                  [T]  AEGIS SENTINEL - DEFENSIVE MONITORING DASHBOARD         
                    ClearGlassCorp Advanced Threat Detection                 
                         CLASSIFICATION: DEFENSE GRADE                        
                                                                              
================================================================================
"@ -ForegroundColor Cyan

            $uptime = ((Get-Date) - $Script:SessionStart).ToString("hh\:mm\:ss")
            $threatStatus = if ($Script:ThreatCount -eq 0) { '[+] SECURE' } else { '[!] THREATS DETECTED' }
            $threatColor = if ($Script:ThreatCount -eq 0) { 'Green' } else { 'Red' }

            Write-Host "`n+-- SYSTEM STATUS " -NoNewline -ForegroundColor Yellow
            Write-Host "$('-' * 60)+" -ForegroundColor DarkGray
            Write-Host "| " -NoNewline -ForegroundColor DarkGray
            Write-Host "STATUS: " -NoNewline -ForegroundColor Yellow
            Write-Host "$threatStatus" -NoNewline -ForegroundColor $threatColor
            Write-Host " | " -NoNewline -ForegroundColor DarkGray
            Write-Host "UPTIME: $uptime" -NoNewline -ForegroundColor Cyan
            Write-Host " | " -NoNewline -ForegroundColor DarkGray
            Write-Host "THREATS: $Script:ThreatCount" -NoNewline -ForegroundColor $(if ($Script:ThreatCount -gt 0) {'Red'} else {'Green'})
            Write-Host " | " -NoNewline -ForegroundColor DarkGray
            Write-Host "LEVEL: $ThreatLevel" -NoNewline -ForegroundColor Magenta
            Write-Host " |" -ForegroundColor DarkGray
            Write-Host "| " -NoNewline -ForegroundColor DarkGray
            Write-Host "HOST: $env:COMPUTERNAME" -NoNewline -ForegroundColor Cyan
            Write-Host " | " -NoNewline -ForegroundColor DarkGray
            Write-Host "ML: " -NoNewline -ForegroundColor Yellow
            Write-Host "$(if ($Script:AEGIS.ML.Enabled) {'ON'} else {'OFF'})" -NoNewline -ForegroundColor $(if ($Script:AEGIS.ML.Enabled) {'Green'} else {'Red'})
            Write-Host " | " -NoNewline -ForegroundColor DarkGray
            Write-Host "FORENSICS: " -NoNewline -ForegroundColor Yellow
            Write-Host "$(if ($Script:AEGIS.Advanced.MemoryForensics) {'ON'} else {'OFF'})" -NoNewline -ForegroundColor $(if ($Script:AEGIS.Advanced.MemoryForensics) {'Green'} else {'Yellow'})
            Write-Host "  |" -ForegroundColor DarkGray
            Write-Host "+$('-' * 78)+" -ForegroundColor DarkGray

            foreach ($job in $detectionJobs) {
                $out = Receive-Job -Job $job -ErrorAction SilentlyContinue
                foreach ($alert in @($out)) {
                    if (-not $alert) { continue }

                    if ($alert -is [hashtable] -or ($alert.PSObject.Properties.Name -contains 'ProcessCount' -and $alert.PSObject.Properties.Name -contains 'CPU')) {
                        $state = @{
                            ProcessCount       = [int]$alert.ProcessCount
                            NetworkConnections = [int]$alert.NetworkConnections
                            CPU                = [double]$alert.CPU
                        }
                        $anoms = Test-BehavioralAnomaly -CurrentState $state
                        foreach ($a in @($anoms)) { $Script:AlertQueue.Add([PSCustomObject]$a) }
                        continue
                    }

                    $Script:AlertQueue.Add($alert)

                    if ($alert.PSObject.Properties.Name -contains 'Score' -and [int]$alert.Score -ge 75) {
                        Invoke-ThreatResponse -Alert $alert | Out-Null
                    }

                    if ($alert.PSObject.Properties.Name -contains 'Score' -and [int]$alert.Score -ge 85) {
                        try { [Console]::Beep(1000, 200) } catch {}
                    }
                }
            }

            if ($Script:AlertQueue.Count -ge 3) {
                $recent = $Script:AlertQueue | Select-Object -Last 25
                $corr = Invoke-ThreatCorrelation -Alerts @($recent)
                foreach ($c in @($corr)) {
                    $Script:AlertQueue.Add($c)
                    Invoke-ThreatResponse -Alert $c | Out-Null
                }
            }

            Write-Host "`n+-- THREAT INTELLIGENCE " -NoNewline -ForegroundColor Red
            Write-Host "$('-' * 53)+" -ForegroundColor DarkGray

            if ($Script:AlertQueue.Count -gt 0) {
                $recentAlerts = $Script:AlertQueue | Select-Object -Last $Script:AEGIS.Dashboard.MaxAlerts
                foreach ($a in $recentAlerts) {
                    $sev = if ($a.Severity) { $a.Severity } else { 'INFO' }
                    $score = if ($a.Score) { $a.Score } else { 0 }
                    $t = if ($a.Timestamp) { ([datetime]$a.Timestamp).ToString('HH:mm:ss') } else { (Get-Date).ToString('HH:mm:ss') }
                    $alertType = if ($a.Type) { $a.Type.ToString().PadRight(25).Substring(0,25) } else { "Unknown".PadRight(25) }
                    $color = switch ($sev) {
                        'CRITICAL' { 'Red' }
                        'HIGH'     { 'Magenta' }
                        'MEDIUM'   { 'Yellow' }
                        default    { 'White' }
                    }
                    Write-Host "| " -NoNewline -ForegroundColor DarkGray
                    Write-Host "$alertType" -NoNewline -ForegroundColor $color
                    Write-Host " [$sev] " -NoNewline -ForegroundColor DarkGray
                    Write-Host "Score:$score".PadRight(10) -NoNewline -ForegroundColor Yellow
                    Write-Host "| $t |" -ForegroundColor DarkGray
                }
            } else {
                Write-Host "| " -NoNewline -ForegroundColor DarkGray
                Write-Host "[+] No threats detected - All systems nominal".PadRight(74) -NoNewline -ForegroundColor Green
                Write-Host " |" -ForegroundColor DarkGray
            }

            Write-Host "+$('-' * 78)+" -ForegroundColor DarkGray

            Write-Host "`n+-- SYSTEM METRICS " -NoNewline -ForegroundColor Yellow
            Write-Host "$('-' * 58)+" -ForegroundColor DarkGray

            try {
                $cpu = 0
                try {
                    $cpuCounter = Get-Counter '\Processor(_Total)\% Processor Time' -ErrorAction SilentlyContinue
                    if ($cpuCounter) { $cpu = $cpuCounter.CounterSamples.CookedValue }
                } catch {}

                $mem = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
                $memPct = if ($mem -and $mem.TotalVisibleMemorySize -gt 0) {
                    [math]::Round((($mem.TotalVisibleMemorySize - $mem.FreePhysicalMemory) / $mem.TotalVisibleMemorySize) * 100, 1)
                } else { 0 }

                $disk = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction SilentlyContinue | Select-Object -First 1
                $diskPct = if ($disk -and $disk.Size -gt 0) {
                    [math]::Round((($disk.Size - $disk.FreeSpace) / $disk.Size) * 100, 1)
                } else { 0 }

                Write-Host "| CPU:    " -NoNewline -ForegroundColor DarkGray
                Write-Host "$([math]::Round($cpu, 1))%".PadRight(8) -NoNewline -ForegroundColor $(if ($cpu -gt 80) {'Red'} elseif ($cpu -gt 60) {'Yellow'} else {'Green'})
                Write-Host "| Memory: " -NoNewline -ForegroundColor DarkGray
                Write-Host "$memPct%".PadRight(8) -NoNewline -ForegroundColor $(if ($memPct -gt 85) {'Red'} elseif ($memPct -gt 70) {'Yellow'} else {'Green'})
                Write-Host "| Disk:   " -NoNewline -ForegroundColor DarkGray
                Write-Host "$diskPct%".PadRight(20) -NoNewline -ForegroundColor $(if ($diskPct -gt 90) {'Red'} elseif ($diskPct -gt 75) {'Yellow'} else {'Green'})
                Write-Host "|" -ForegroundColor DarkGray
            } catch {}

            Write-Host "| " -NoNewline -ForegroundColor DarkGray
            Write-Host "ENGINES ACTIVE: ".PadRight(18) -NoNewline -ForegroundColor Yellow
            $running = @($detectionJobs | Where-Object { $_.State -eq 'Running' }).Count
            $total = @($detectionJobs).Count
            Write-Host "$running/$total".PadRight(57) -NoNewline -ForegroundColor $(if ($running -eq $total) {'Green'} else {'Yellow'})
            Write-Host "|" -ForegroundColor DarkGray

            Write-Host "+$('-' * 78)+" -ForegroundColor DarkGray

            Write-Host "`n+-- DETECTION MODULES " -NoNewline -ForegroundColor Yellow
            Write-Host "$('-' * 55)+" -ForegroundColor DarkGray

            $modules = @($detectionJobs | Where-Object { $_.State -eq 'Running' } | Select-Object -First 8)
            foreach ($mod in $modules) {
                Write-Host "| [+] " -NoNewline -ForegroundColor Green
                Write-Host "$($mod.Name)".PadRight(71) -NoNewline -ForegroundColor White
                Write-Host "|" -ForegroundColor DarkGray
            }

            Write-Host "+$('-' * 78)+" -ForegroundColor DarkGray

            Write-Host "`n+-- NETWORK ACTIVITY " -NoNewline -ForegroundColor Yellow
            Write-Host "$('-' * 56)+" -ForegroundColor DarkGray

            try {
                $estab = @(Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue).Count
                $listen = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue).Count

                Write-Host "| Established Connections: " -NoNewline -ForegroundColor Cyan
                Write-Host "$estab".PadRight(49) -NoNewline -ForegroundColor White
                Write-Host "|" -ForegroundColor DarkGray

                Write-Host "| Listening Ports:         " -NoNewline -ForegroundColor Cyan
                Write-Host "$listen".PadRight(49) -NoNewline -ForegroundColor White
                Write-Host "|" -ForegroundColor DarkGray
            } catch {}

            Write-Host "+$('-' * 78)+" -ForegroundColor DarkGray

            if ($Script:AEGIS.ML.Enabled -and $Script:MLBaseline) {
                Write-Host "`n+-- MACHINE LEARNING INSIGHTS " -NoNewline -ForegroundColor Blue
                Write-Host "$('-' * 46)+" -ForegroundColor DarkGray

                Write-Host "| [ML] Baseline Samples: " -NoNewline -ForegroundColor Blue
                Write-Host "$($Script:MLBaseline.SampleCount)".PadRight(53) -NoNewline -ForegroundColor Cyan
                Write-Host "|" -ForegroundColor DarkGray

                Write-Host "| [ML] Confidence Threshold: " -NoNewline -ForegroundColor Blue
                Write-Host "$($Script:AEGIS.ML.ConfidenceThreshold * 100)%".PadRight(49) -NoNewline -ForegroundColor Cyan
                Write-Host "|" -ForegroundColor DarkGray

                Write-Host "+$('-' * 78)+" -ForegroundColor DarkGray
            }

            Write-Host "`n$('=' * 80)" -ForegroundColor DarkGray
            Write-Host "Version $($Script:AEGIS.Product.Version) | Build $($Script:AEGIS.Product.Build) | Codename: $($Script:AEGIS.Product.Codename) | Refresh: $($Script:AEGIS.Dashboard.RefreshInterval)s" -ForegroundColor DarkGray
            Write-Host "Press Ctrl+C to exit | Classification: $($Script:AEGIS.Product.Classification) | $($Script:AEGIS.Product.Copyright)" -ForegroundColor DarkGray
            Write-Host "$('=' * 80)" -ForegroundColor DarkGray

            Start-Sleep -Seconds $Script:AEGIS.Dashboard.RefreshInterval
        }
    }
    finally {
        Write-AegisLog "Stopping detection jobs..." -Level INFO -Component DASHBOARD
        foreach ($j in @($Script:ActiveJobs)) {
            try { Stop-Job -Job $j -Force -ErrorAction SilentlyContinue } catch {}
            try { Remove-Job -Job $j -Force -ErrorAction SilentlyContinue } catch {}
        }
    }
}

# ═══════════════════════════════════════════════════════════════════════════════
# DEPLOYMENT & HARDENING
# ═══════════════════════════════════════════════════════════════════════════════

function Deploy-Deception {
    Write-AegisLog "Deploying deception artifacts..." -Level INFO -Component DECEPTION

    $honeytokens = @('backup_admin', 'service_sql', 'readonly_app', 'admin_test', 'web_deploy', 'db_backup')
    foreach ($token in $honeytokens) {
        try {
            $password = -join ((65..90) + (97..122) + (48..57) | Get-Random -Count 32 | ForEach-Object { [char]$_ })
            $securePass = ConvertTo-SecureString $password -AsPlainText -Force

            New-LocalUser -Name $token -Password $securePass -Description "Honeytoken Account" -ErrorAction SilentlyContinue | Out-Null
            Disable-LocalUser -Name $token -ErrorAction SilentlyContinue

            Write-AegisLog "Honeytoken created/disabled: $token" -Level SUCCESS -Component DECEPTION
        } catch {}
    }

    $decoyPath = "$env:ProgramData\ClearGlassCorp\Honeypots"
    if (-not (Test-Path $decoyPath)) { New-Item -ItemType Directory -Path $decoyPath -Force | Out-Null }

    $decoys = @{
        'passwords.txt'            = "admin:Password123`nroot:Admin2024`nsa:P@ssw0rd"
        'database_credentials.sql' = "USE master; CREATE LOGIN sa WITH PASSWORD = 'Admin123!'"
        'api_keys.json'            = '{"aws_key":"AKIAIOSFODNN7EXAMPLE","azure_key":"abcd1234"}'
        'ssh_keys.pem'             = "-----BEGIN RSA PRIVATE KEY-----`nMIIEpAIBAAKCAQEA...`n-----END RSA PRIVATE KEY-----"
        'vpn_config.ovpn'          = "client`ndev tun`nremote vpn.company.com 1194"
    }

    foreach ($file in $decoys.Keys) {
        try { Set-Content -Path (Join-Path $decoyPath $file) -Value $decoys[$file] -Encoding UTF8 } catch {}
    }

    Write-AegisLog "Deception deployment complete" -Level SUCCESS -Component DECEPTION
}

function Start-AegisDeployment {
    Write-Host "`n=== AEGIS SENTINEL DEPLOYMENT / HARDENING ===`n" -ForegroundColor Cyan
    Write-AegisLog "Starting deployment/hardening steps" -Level INFO -Component DEPLOY

    $steps = @(
        @{Name='Enable Defender realtime'; Action={
            if (Get-Command Set-MpPreference -ErrorAction SilentlyContinue) {
                Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction SilentlyContinue
                Set-MpPreference -MAPSReporting Advanced -ErrorAction SilentlyContinue
            }
        }},
        @{Name='Enable Firewall (All Profiles)'; Action={
            Set-NetFirewallProfile -All -Enabled True -DefaultInboundAction Block -DefaultOutboundAction Allow -ErrorAction SilentlyContinue
        }},
        @{Name='Disable SMBv1'; Action={
            Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart -WarningAction SilentlyContinue | Out-Null
        }},
        @{Name='Enable Advanced Audit (selected)'; Action={
            auditpol /set /subcategory:"Logon" /success:enable /failure:enable | Out-Null
            auditpol /set /subcategory:"Process Creation" /success:enable /failure:enable | Out-Null
            auditpol /set /subcategory:"Registry" /success:enable /failure:enable | Out-Null
        }},
        @{Name='Enable PowerShell ScriptBlock logging'; Action={
            $basePath = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell'
            $path = "$basePath\ScriptBlockLogging"
            if (-not (Test-Path $basePath)) {
                New-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows' -Name 'PowerShell' -Force | Out-Null
            }
            if (-not (Test-Path $path)) {
                New-Item -Path $basePath -Name 'ScriptBlockLogging' -Force | Out-Null
            }
            Set-ItemProperty -Path $path -Name EnableScriptBlockLogging -Value 1 -ErrorAction SilentlyContinue
            Set-ItemProperty -Path $path -Name EnableScriptBlockInvocationLogging -Value 1 -ErrorAction SilentlyContinue
        }},
        @{Name='Enable LSASS PPL (if supported)'; Action={
            Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name RunAsPPL -Value 1 -ErrorAction SilentlyContinue
        }},
        @{Name='Disable PowerShell v2'; Action={
            Disable-WindowsOptionalFeature -Online -FeatureName MicrosoftWindowsPowerShellV2Root -NoRestart -WarningAction SilentlyContinue | Out-Null
        }},
        @{Name='Set ExecutionPolicy RemoteSigned (LocalMachine)'; Action={
            Set-ExecutionPolicy RemoteSigned -Scope LocalMachine -Force
        }}
    )

    if ($DeployDeception) {
        $steps += @{Name='Deploy deception artifacts'; Action={ Deploy-Deception }}
    }

    $i = 0
    foreach ($step in $steps) {
        $i++
        Write-Host "[$i/$($steps.Count)] $($step.Name)..." -ForegroundColor Yellow
        try {
            & $step.Action
            Write-Host "  [+] Complete" -ForegroundColor Green
            Write-AegisLog "$($step.Name) completed" -Level SUCCESS -Component DEPLOY
        } catch {
            Write-Host "  [!] Warning: $($_.Exception.Message)" -ForegroundColor Yellow
            Write-AegisLog "$($step.Name) failed: $($_.Exception.Message)" -Level WARNING -Component DEPLOY
        }
    }

    Write-Host "`n[+] DEPLOYMENT COMPLETE`n" -ForegroundColor Green
    Write-Host "Recommended Next Steps:" -ForegroundColor Yellow
    Write-Host "  1. Launch dashboard: " -NoNewline -ForegroundColor Cyan
    Write-Host "-Mode Dashboard -EnableML -EnableForensics" -ForegroundColor White
    Write-Host "  2. Run threat hunt: " -NoNewline -ForegroundColor Cyan
    Write-Host "-Mode Hunt -EnableForensics" -ForegroundColor White
    Write-Host "  3. Enable paranoid mode: " -NoNewline -ForegroundColor Cyan
    Write-Host "-ThreatLevel Paranoid -AutoRemediate" -ForegroundColor White

    Write-AegisLog "Deployment completed successfully" -Level SUCCESS -Component DEPLOY
}

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
    ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "`n[X] ADMINISTRATOR PRIVILEGES REQUIRED`n" -ForegroundColor Red
    Write-Host "Right-click PowerShell -> Run as Administrator" -ForegroundColor Yellow
    exit 1
}

Clear-Host
Write-Host @"
================================================================================
                                                                              
                    [T]  AEGIS SENTINEL v$($Script:AEGIS.Product.Version) - ENTERPRISE EDITION              
                         ClearGlassCorp Defense Division                     
                      Next-Generation Threat Detection                       
                                                                              
                  CLASSIFICATION: $($Script:AEGIS.Product.Classification.ToUpper().PadRight(32))      
                                                                              
================================================================================

"@ -ForegroundColor Cyan

Write-Host "Codename: " -NoNewline -ForegroundColor Yellow
Write-Host "$($Script:AEGIS.Product.Codename)" -ForegroundColor Magenta
Write-Host "Build: " -NoNewline -ForegroundColor Yellow
Write-Host "$($Script:AEGIS.Product.Build)" -ForegroundColor Cyan
Write-Host "Threat Level: " -NoNewline -ForegroundColor Yellow
Write-Host "$ThreatLevel" -ForegroundColor $(switch ($ThreatLevel) { 'Paranoid' {'Red'} 'Aggressive' {'Yellow'} default {'Green'}})
Write-Host "$($Script:AEGIS.Product.Copyright)" -ForegroundColor DarkGray
Write-Host ""

Write-AegisLog "AEGIS SENTINEL initialized - Enterprise Edition" -Level INFO -Component CORE

switch ($Mode) {
    'Deploy' {
        Start-AegisDeployment
    }

    'Monitor' {
        Write-Host "Initializing continuous threat monitoring..." -ForegroundColor Green
        Show-AdvancedDashboard
    }

    'Dashboard' {
        Show-AdvancedDashboard
    }

    'Hunt' {
        Write-Host "Initiating threat hunting..." -ForegroundColor Green
        Write-Host "Duration: $HuntDuration seconds | Forensics: $(if ($EnableForensics) {'ENABLED'} else {'DISABLED'})" -ForegroundColor Cyan
        Write-Host ""

        if ($Script:AEGIS.ML.Enabled) {
            Initialize-MLBaseline | Out-Null
        }

        $jobs = Start-AdvancedDetection

        if ($EnableForensics) {
            Write-Host "`nRunning memory forensics..." -ForegroundColor Cyan
            $forensics = Start-MemoryForensics

            if ($forensics -and @($forensics).Count -gt 0) {
                Write-Host "`n=== FORENSIC FINDINGS ===" -ForegroundColor Cyan
                $forensics | Format-List
            }
        }

        Write-Host "`nMonitoring for $HuntDuration seconds..." -ForegroundColor Yellow
        Start-Sleep -Seconds $HuntDuration

        Write-Host "`n=== THREAT HUNT RESULTS ===" -ForegroundColor Cyan
        foreach ($job in $jobs) {
            $results = @(Receive-Job -Job $job -ErrorAction SilentlyContinue)
            if ($results.Count -gt 0) {
                Write-Host "`n[$($job.Name)]" -ForegroundColor Yellow
                $results | Format-Table -AutoSize
            }
            Stop-Job -Job $job -ErrorAction SilentlyContinue
            Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
        }
    }

    'Investigate' {
        if (-not $IncidentID) {
            Write-Host "ERROR: -IncidentID parameter required for investigation mode" -ForegroundColor Red
            exit 1
        }

        Write-Host "Investigating incident: $IncidentID" -ForegroundColor Yellow

        Write-Host "`nRunning deep forensic analysis..." -ForegroundColor Cyan
        $forensics = Start-MemoryForensics

        Write-Host "`n=== INVESTIGATION REPORT ===" -ForegroundColor Cyan
        Write-Host "Incident ID: $IncidentID" -ForegroundColor Yellow
        Write-Host "Timestamp: $(Get-Date)" -ForegroundColor Cyan
        Write-Host "`nFindings:" -ForegroundColor Yellow
        if ($forensics -and @($forensics).Count -gt 0) {
            $forensics | Format-List
        } else {
            Write-Host "No suspicious findings detected." -ForegroundColor Green
        }
    }

    'Research' {
        Write-Host "Entering RESEARCH MODE - Experimental Detection Algorithms" -ForegroundColor Magenta
        Write-Host "WARNING: This mode enables experimental features that may generate false positives" -ForegroundColor Yellow
        Write-Host ""

        $Script:AEGIS.Advanced.ZeroDayHeuristics = $true
        $Script:AEGIS.ML.Enabled = $true
        $Script:AEGIS.Advanced.MemoryForensics = $true

        Show-AdvancedDashboard
    }

    'Audit' {
        Write-Host "Running security audit..." -ForegroundColor Cyan

        if ($Script:AEGIS.ML.Enabled) {
            Initialize-MLBaseline | Out-Null
        }

        $forensics = Start-MemoryForensics

        Write-Host "`n=== SECURITY AUDIT REPORT ===" -ForegroundColor Cyan
        Write-Host "Timestamp: $(Get-Date)" -ForegroundColor Yellow
        Write-Host "Host: $env:COMPUTERNAME" -ForegroundColor Cyan
        Write-Host "`nForensic Findings:" -ForegroundColor Yellow
        if ($forensics -and @($forensics).Count -gt 0) {
            $forensics | Format-Table -AutoSize
        } else {
            Write-Host "No suspicious findings." -ForegroundColor Green
        }
    }

    default {
        Write-Host "Unknown mode: $Mode" -ForegroundColor Red
        exit 1
    }
}

Write-AegisLog "AEGIS session ended" -Level INFO -Component CORE
