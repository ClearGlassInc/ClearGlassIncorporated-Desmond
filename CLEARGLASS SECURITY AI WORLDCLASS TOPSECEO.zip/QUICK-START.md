# AEGIS SENTINEL - Quick Start Guide

## Installation (2 Minutes)

### Step 1: Extract Package
Extract `AEGIS-SENTINEL-v3.0.1.zip` to a location of your choice (e.g., `C:\Tools\AEGIS\`)

### Step 2: Open PowerShell as Administrator
- Press `Win + X`
- Select "Windows Terminal (Admin)" or "PowerShell (Admin)"

### Step 3: Navigate to AEGIS Directory
```powershell
cd C:\Tools\AEGIS
```

### Step 4: Run AEGIS
```powershell
.\AEGIS-SENTINEL.ps1 -Mode Dashboard
```

---

## First-Time Setup Recommendation

For your first run, we recommend deploying the hardening configurations:

```powershell
.\AEGIS-SENTINEL.ps1 -Mode Deploy
```

This will:
- Enable Windows Defender real-time protection
- Configure Windows Firewall
- Enable security audit policies
- Enable PowerShell logging
- Apply LSASS protection

---

## Common Usage Scenarios

### Daily Monitoring
```powershell
.\AEGIS-SENTINEL.ps1 -Mode Dashboard -ThreatLevel Standard
```

### High-Security Environment
```powershell
.\AEGIS-SENTINEL.ps1 -Mode Dashboard -ThreatLevel Aggressive -EnableML -EnableForensics
```

### Incident Response
```powershell
.\AEGIS-SENTINEL.ps1 -Mode Hunt -HuntDuration 600 -EnableForensics
```

### Security Assessment
```powershell
.\AEGIS-SENTINEL.ps1 -Mode Audit -EnableML -EnableForensics
```

---

## Dashboard Overview

When running in Dashboard mode, you'll see:

```
================================================================================
                  [T]  AEGIS SENTINEL - DEFENSIVE MONITORING DASHBOARD         
================================================================================

+-- SYSTEM STATUS ----------------------------------------------------------+
| STATUS: [+] SECURE | UPTIME: 00:05:23 | THREATS: 0 | LEVEL: Standard      |
+--------------------------------------------------------------------------+

+-- THREAT INTELLIGENCE ----------------------------------------------------+
| [+] No threats detected - All systems nominal                             |
+--------------------------------------------------------------------------+

+-- SYSTEM METRICS ---------------------------------------------------------+
| CPU: 12.5%  | Memory: 45.2%  | Disk: 62.1%                               |
+--------------------------------------------------------------------------+

+-- DETECTION MODULES ------------------------------------------------------+
| [+] ZeroDayHeuristics                                                     |
| [+] SupplyChainMonitor                                                    |
| [+] APTDetection                                                          |
| [+] NetworkAnomalyEngine                                                  |
| [+] RegistryMonitor                                                       |
| [+] EvasionDetection                                                      |
+--------------------------------------------------------------------------+
```

Press `Ctrl+C` to exit the dashboard.

---

## Threat Severity Levels

| Color | Severity | Score Range | Action Required |
|-------|----------|-------------|-----------------|
| 🔴 Red | CRITICAL | 90-100 | Immediate investigation |
| 🟣 Magenta | HIGH | 75-89 | Urgent review |
| 🟡 Yellow | MEDIUM | 50-74 | Scheduled review |
| ⚪ White | LOW | 0-49 | Monitor |

---

## Where to Find Logs

All logs are stored in:
```
%ProgramData%\ClearGlassCorp\AEGIS\Logs\
```

Incident reports are in:
```
%ProgramData%\ClearGlassCorp\AEGIS\Logs\Incidents\
```

---

## Need Help?

- Full documentation: See `README.md`
- User Guide: See `AEGIS-UserGuide.docx`
- Support: support@clearglasscorp.com
- Website: https://clearglasscorp.com

---

© 2026 ClearGlassCorp. All Rights Reserved.
