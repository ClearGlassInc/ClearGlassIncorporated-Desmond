# AEGIS SENTINEL v3.0.1 - Enterprise Edition

## ClearGlassCorp Advanced Endpoint Defense Platform

![Version](https://img.shields.io/badge/Version-3.0.1-blue)
![PowerShell](https://img.shields.io/badge/PowerShell-5.1+-green)
![Windows](https://img.shields.io/badge/Windows-10%2F11%2FServer%202019+-orange)
![License](https://img.shields.io/badge/License-Commercial-red)

---

## Overview

**AEGIS SENTINEL** is an enterprise-grade endpoint detection and response (EDR) platform designed for organizations requiring advanced threat detection capabilities. Built entirely in PowerShell for maximum compatibility and zero external dependencies, AEGIS provides defense-grade security monitoring without the complexity of traditional EDR solutions.

---

## Key Features

### Detection Capabilities

| Feature | Description |
|---------|-------------|
| **AI/ML Behavioral Analytics** | Baseline-driven anomaly detection for processes, network, and system behavior |
| **Memory Forensics** | Hidden process detection, LSASS integrity monitoring, rootkit heuristics |
| **Zero-Day Heuristics** | Script execution pattern analysis and suspicious process chain detection |
| **APT Detection** | Advanced Persistent Threat indicators including persistence and lateral movement |
| **Network Anomaly Engine** | Beaconing detection, unusual port activity, connection pattern analysis |
| **Supply Chain Monitoring** | Unsigned binary detection and update mechanism tampering alerts |
| **Registry Monitor** | Critical registry key modification tracking |
| **Evasion Detection** | Timestomping, process hollowing, and defense evasion technique identification |

### Operational Modes

- **Dashboard** - Real-time threat monitoring with live metrics
- **Monitor** - Continuous background threat detection
- **Hunt** - Time-bounded active threat hunting
- **Investigate** - Deep forensic analysis of specific incidents
- **Deploy** - System hardening and configuration
- **Audit** - Point-in-time security assessment
- **Research** - Experimental detection algorithms (higher sensitivity)

### Threat Levels

- **Standard** - Balanced detection with minimal false positives
- **Aggressive** - Enhanced sensitivity for higher-risk environments
- **Paranoid** - Maximum detection for critical infrastructure

---

## System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| **OS** | Windows 10 20H2 / Server 2019 | Windows 11 / Server 2022 |
| **PowerShell** | 5.1 | 7.x |
| **RAM** | 8 GB | 16 GB |
| **.NET Framework** | 4.8 | 4.8+ |
| **Privileges** | Administrator | Administrator |

---

## Quick Start

### 1. Download and Extract

Extract the AEGIS package to your desired location.

### 2. Launch Dashboard (Recommended First Run)

```powershell
# Run as Administrator
.\AEGIS-SENTINEL.ps1 -Mode Dashboard -ThreatLevel Standard
```

### 3. Enable Advanced Features

```powershell
# Full protection with ML and Forensics
.\AEGIS-SENTINEL.ps1 -Mode Dashboard -ThreatLevel Aggressive -EnableML -EnableForensics
```

---

## Usage Examples

### Real-Time Monitoring

```powershell
# Standard monitoring dashboard
.\AEGIS-SENTINEL.ps1 -Mode Dashboard

# Aggressive monitoring with ML
.\AEGIS-SENTINEL.ps1 -Mode Dashboard -ThreatLevel Aggressive -EnableML
```

### Threat Hunting

```powershell
# 5-minute threat hunt with forensics
.\AEGIS-SENTINEL.ps1 -Mode Hunt -HuntDuration 300 -EnableForensics

# Extended hunt with ML analytics
.\AEGIS-SENTINEL.ps1 -Mode Hunt -HuntDuration 3600 -EnableML -EnableForensics
```

### System Hardening

```powershell
# Deploy hardening configurations
.\AEGIS-SENTINEL.ps1 -Mode Deploy

# Deploy with honeypot/deception artifacts
.\AEGIS-SENTINEL.ps1 -Mode Deploy -DeployDeception
```

### Incident Investigation

```powershell
# Investigate specific incident
.\AEGIS-SENTINEL.ps1 -Mode Investigate -IncidentID "AEGIS-20260118-143022-1234"
```

### Security Audit

```powershell
# Run point-in-time security audit
.\AEGIS-SENTINEL.ps1 -Mode Audit -EnableML -EnableForensics
```

---

## Parameters Reference

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `-Mode` | String | Dashboard | Operation mode (Deploy, Monitor, Hunt, Investigate, Audit, Dashboard, Research) |
| `-ThreatLevel` | String | Standard | Detection sensitivity (Standard, Aggressive, Paranoid) |
| `-IncidentID` | String | - | Incident ID for investigation mode |
| `-HuntDuration` | Int | 300 | Hunt duration in seconds (30-86400) |
| `-EnableML` | Switch | False | Enable ML behavioral analytics |
| `-EnableForensics` | Switch | False | Enable memory forensics |
| `-AutoRemediate` | Switch | False | Enable automated threat containment |
| `-DeployDeception` | Switch | False | Deploy honeypot artifacts |
| `-Silent` | Switch | False | Suppress console output |

---

## Detection Engines

AEGIS runs multiple concurrent detection engines:

1. **ZeroDayHeuristics** - Script interpreter abuse and unusual process spawning
2. **SupplyChainMonitor** - Update mechanism tampering and unsigned binaries
3. **APTDetection** - Long-running suspicious processes and persistence mechanisms
4. **NetworkAnomalyEngine** - C2 beaconing and unusual network activity
5. **RegistryMonitor** - Critical registry key modifications
6. **EvasionDetection** - Anti-forensics and evasion technique identification
7. **BaselineAnalytics** - ML-powered behavioral anomaly detection (when enabled)

---

## Log Structure

All logs are stored in: `%ProgramData%\ClearGlassCorp\AEGIS\Logs\`

```
Logs/
├── Threats/          # Threat detection logs
├── Forensics/        # Memory forensics findings
├── Audit/            # General audit logs
├── MachineLearning/  # ML baseline and analytics
├── Network/          # Network activity logs
├── Memory/           # Memory analysis logs
├── Research/         # Research mode logs
└── Incidents/        # Incident reports (JSON)
```

---

## Incident Reports

When threats are detected, AEGIS generates JSON incident reports:

```json
{
  "IncidentId": "AEGIS-20260118-143022-1234",
  "Timestamp": "2026-01-18T14:30:22.000Z",
  "Alert": {
    "Type": "APTIndicators",
    "Severity": "CRITICAL",
    "Score": 95
  },
  "System": {
    "Computer": "WORKSTATION01",
    "User": "admin",
    "Domain": "CORP"
  }
}
```

---

## Hardening Actions (Deploy Mode)

The Deploy mode applies the following security configurations:

- Enable Windows Defender real-time protection
- Enable Windows Firewall (all profiles)
- Disable SMBv1 protocol
- Enable advanced audit policies (Logon, Process Creation, Registry)
- Enable PowerShell ScriptBlock logging
- Configure LSASS PPL protection
- Disable PowerShell v2
- Set execution policy to RemoteSigned

---

## Deception Artifacts

When `-DeployDeception` is enabled:

**Honeytoken Accounts** (disabled by default):
- backup_admin
- service_sql
- readonly_app
- admin_test
- web_deploy
- db_backup

**Decoy Files** (in `%ProgramData%\ClearGlassCorp\Honeypots\`):
- passwords.txt
- database_credentials.sql
- api_keys.json
- ssh_keys.pem
- vpn_config.ovpn

---

## Important Notes

### Limitations

- PowerShell cannot perform true kernel-level monitoring or DPI without additional drivers
- Memory forensics operates in user-mode only (best-effort heuristics)
- Some detection engines require specific Windows audit policies to be enabled
- Registry monitoring requires Event ID 4657 (registry auditing enabled)

### Auto-Remediation Warning

The `-AutoRemediate` flag enables automatic threat containment:

- **Score ≥ 90**: May disable network adapters (with confirmation prompt)
- **Score ≥ 75**: Logs warning for manual intervention

Use with caution in production environments. Network adapters can be restored using the `Restore-NetworkAdapters` function.

---

## Support

**ClearGlassCorp Defense Division**

- Website: https://clearglasscorp.com
- Email: support@clearglasscorp.com
- Documentation: https://docs.clearglasscorp.com/aegis

---

## Version History

| Version | Date | Notes |
|---------|------|-------|
| 3.0.1 | January 2026 | Enterprise Edition - Stability improvements, ACL fixes |
| 3.0.0 | December 2025 | Major release - ML analytics, correlation engine |
| 2.5.0 | October 2025 | Memory forensics, deception deployment |
| 2.0.0 | July 2025 | Multi-engine detection, dashboard |
| 1.0.0 | March 2025 | Initial release |

---

© 2026 ClearGlassCorp. All Rights Reserved.

**AEGIS SENTINEL** - Defense Grade Endpoint Protection
